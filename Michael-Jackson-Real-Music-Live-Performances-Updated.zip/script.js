// Subtle reveal effects for the first page.
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.fact, .legacy h2, .legacy h3, .intro').forEach((item) => {
  item.classList.add('reveal');
  observer.observe(item);
});
