// Subtle reveal effects for the first page.
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.fact, .legacy h2, .legacy h3, .intro').forEach((item) => {
  item.classList.add('reveal');
  observer.observe(item);
});


// Start the embedded MJ playlist after the visitor's deliberate tap.
document.addEventListener('DOMContentLoaded', () => {
  const playAll = document.getElementById('mjPlayAll');
  const player = document.getElementById('mjPlaylistPlayer');
  if (playAll && player) {
    playAll.addEventListener('click', () => {
      player.src = 'https://www.youtube-nocookie.com/embed/videoseries?list=PLUeQUfurHN6bjde_KttpUONL9C0wjJvGF&index=0&autoplay=1&rel=0';
      playAll.textContent = 'PLAYING • MJ PLAYLIST';
      playAll.disabled = true;
      playAll.setAttribute('aria-label', 'Michael Jackson playlist started');
    });
  }
});
