const albums = [
  {title:"Off the Wall",year:"1979",query:"Michael Jackson Off the Wall",description:"Jackson’s breakthrough as a mature solo artist blended disco, funk, soul and pop. Produced by Quincy Jones, it helped establish the sound and confidence that would lead into his biggest decade.",sales:"Reported global estimate: around 20 million copies. U.S. certification: 9× Platinum (reported in discography references).",record:"Earned Grammy recognition, including Best Male R&B Vocal Performance for “Don’t Stop ’Til You Get Enough”; its four major singles helped make Jackson a leading solo star."},
  {title:"Thriller",year:"1982",query:"Michael Jackson Thriller",description:"A landmark pop album combining pop, rock, R&B and funk. Its short films and worldwide singles made it a defining cultural moment.",sales:"Guinness World Records describes it as the world’s best-selling album, estimated at more than 67 million copies worldwide. RIAA certified 34× Platinum in the U.S. in 2021.",record:"The best-selling album in history according to Guinness World Records; it produced seven U.S. Top 10 singles."},
  {title:"Bad",year:"1987",query:"Michael Jackson Bad",description:"A bold, tightly produced album that moved between pop, rock, funk and ballads, with a striking visual identity and a major world tour.",sales:"Historical reported estimate: around 30 million worldwide; U.S. sales certification reported at 8 million in 2009.",record:"Five singles from the album reached No. 1 on the U.S. Billboard Hot 100 — a record at the time for a single album."},
  {title:"Dangerous",year:"1991",query:"Michael Jackson Dangerous",description:"A new musical chapter shaped by new jack swing, pop, R&B and gospel influences, with elaborate visuals and ambitious production.",sales:"Historical reported estimate: around 32 million worldwide; U.S. sales certification reported at 7 million in 2009.",record:"Debuted at No. 1 on the Billboard 200 and became one of the major global album releases of the early 1990s."},
  {title:"HIStory: Past, Present and Future, Book I",year:"1995",query:"Michael Jackson HIStory Past Present and Future Book I",description:"A two-disc project pairing a greatest-hits collection with a set of new songs, reflecting on fame, public scrutiny and personal conviction.",sales:"Historical reported estimate: around 20 million worldwide; U.S. sales certification reported at 3.5 million in 2009.",record:"The first-disc hits collection and new studio material made it an unusually ambitious double album; it debuted at No. 1 in several countries."},
  {title:"Blood on the Dance Floor: HIStory in the Mix",year:"1997",query:"Michael Jackson Blood on the Dance Floor HIStory in the Mix",description:"A remix-focused release built around five new tracks and remixes from the HIStory era, with a darker electronic and dance sound.",sales:"Reliable, consistently comparable worldwide sales totals are not available; figures vary across sources.",record:"No single, consistently verified sales record is claimed here; the release is notable as a full-length remix project."},
  {title:"Invincible",year:"2001",query:"Michael Jackson Invincible",description:"Jackson’s final studio album released during his lifetime, combining contemporary R&B, pop, ballads and orchestral textures.",sales:"Historical reported estimate: around 10 million worldwide; U.S. sales certification reported at 2 million in 2009.",record:"Debuted at No. 1 on the Billboard 200 and in multiple countries."},
  {title:"Michael",year:"2010",query:"Michael Jackson Michael 2010 album",description:"A posthumous album released after Jackson’s death, featuring recordings from different stages of his later career.",sales:"No single independently verified worldwide total is presented here; reported figures vary.",record:"A posthumous release that reached No. 1 in several international album charts."},
  {title:"Xscape",year:"2014",query:"Michael Jackson Xscape",description:"A posthumous collection of previously unreleased recordings, with contemporary production on the main edition and original versions included on the deluxe edition.",sales:"No single independently verified worldwide total is presented here; reported figures vary.",record:"Its contemporary reworkings introduced previously unreleased recordings to a new audience; the deluxe edition also included original versions."}
];

const grid = document.getElementById("albumGrid");
function renderAlbums(){
  grid.innerHTML = "";
  albums.forEach((album, index) => {
    const card = document.createElement("article");
    card.className = "album-card reveal";
    const fallback = document.createElement("div");
    fallback.className = "cover-fallback";
    fallback.innerHTML = album.title.toUpperCase().replace(": ","<br>");
    const info = document.createElement("div");
    info.className = "album-info";
    info.innerHTML = `<p class="album-year">${album.year}</p><h3>${album.title}</h3><p>${album.description}</p><span class="album-stat"><b>SALES / CERTIFICATION</b><br>${album.sales}<br><br><b>RECORD / MILESTONE</b><br>${album.record}</span>`;
    card.appendChild(fallback);
    card.appendChild(info);
    grid.appendChild(card);

    // Fetch album artwork from Apple's public iTunes catalog.
    fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(album.query)}&entity=album&limit=8`)
      .then(response => response.json())
      .then(data => {
        if (!data.results || !data.results.length) return;
        const match = data.results.find(item => item.collectionName.toLowerCase().includes(album.title.split(":")[0].toLowerCase())) || data.results[0];
        const img = document.createElement("img");
        img.className = "album-cover";
        img.src = match.artworkUrl100 ? match.artworkUrl100.replace("100x100bb", "600x600bb") : match.artworkUrl60;
        img.alt = `${album.title} album cover`;
        img.loading = "lazy";
        img.onerror = () => img.remove();
        card.replaceChild(img, fallback);
      }).catch(() => {});
  });
}
renderAlbums();

const observer = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if(entry.isIntersecting){
      entry.target.classList.add("visible");
      const theme = entry.target.closest("[data-theme]")?.dataset.theme;
      if(theme) document.documentElement.dataset.theme = theme;
    }
  });
},{threshold:.12});
document.querySelectorAll(".reveal").forEach(el => observer.observe(el));

const progress = document.getElementById("progress");
window.addEventListener("scroll", () => {
  const max = document.documentElement.scrollHeight - window.innerHeight;
  progress.style.width = `${max > 0 ? (window.scrollY / max) * 100 : 0}%`;
});

const toggle = document.getElementById("menuToggle");
const nav = document.getElementById("nav");
toggle.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  toggle.setAttribute("aria-expanded", String(open));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  toggle.setAttribute("aria-expanded","false");
}));
