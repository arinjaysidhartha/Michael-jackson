// Subtle reveal effects for the first page.
const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.fact, .legacy h2, .legacy h3, .intro').forEach((item) => {
  item.classList.add('reveal');
  observer.observe(item);
});

// Top-right Home Page / Albums menu
const menuToggle = document.getElementById('menuToggle');
const siteMenu = document.getElementById('siteMenu');
if (menuToggle && siteMenu) {
  menuToggle.addEventListener('click', () => {
    const isOpen = siteMenu.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
  });
  siteMenu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    siteMenu.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
  }));
  document.addEventListener('click', event => {
    if (!siteMenu.contains(event.target) && !menuToggle.contains(event.target)) {
      siteMenu.classList.remove('open');
      menuToggle.setAttribute('aria-expanded', 'false');
    }
  });
}
